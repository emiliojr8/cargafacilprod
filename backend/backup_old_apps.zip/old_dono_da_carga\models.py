from django.contrib.auth.models import AbstractUser
from django.db import models
from django.contrib.gis.db.models import PointField
from django.contrib.auth import get_user_model

# Modelo de usuário personalizado para o dono da carga
class DonoDaCarga(AbstractUser):
    telefone = models.CharField(max_length=15)
    endereco = models.CharField(max_length=255)
    localizacao = PointField(null=True, blank=True)

    # Campos de permissões e grupos
    groups = models.ManyToManyField(
        'auth.Group',
        verbose_name='groups',
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
        related_name='donodacarga_groups',  # Nome personalizado
        related_query_name='donodacarga',
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        verbose_name='user permissions',
        blank=True,
        help_text='Specific permissions for this user.',
        related_name='donodacarga_user_permissions',  # Nome personalizado
        related_query_name='donodacarga',
    )

    def __str__(self):
        return self.username

# Modelo de motorista
class Motorista(models.Model):
    user = models.OneToOneField(DonoDaCarga, on_delete=models.CASCADE, related_name='motorista')
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    disponivel = models.BooleanField(default=True)
    veiculo = models.CharField(max_length=100)
    capacidade_carga = models.FloatField()

    def __str__(self):
        return f"{self.user.username} - {self.veiculo}"

# Modelo de transporte
class Transporte(models.Model):
    partida = models.CharField(max_length=255)
    destino = models.CharField(max_length=255)
    tipoCarga = models.CharField(max_length=50, blank=True, null=True)
    dimensoes = models.JSONField(blank=True, null=True)  # Armazena largura, altura, comprimento
    usuario = models.ForeignKey(DonoDaCarga, on_delete=models.CASCADE, related_name='transportes')
    latitude = models.FloatField(blank=True, null=True)
    longitude = models.FloatField(blank=True, null=True)
    data_criacao = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Transporte de {self.partida} para {self.destino}"