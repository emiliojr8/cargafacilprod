from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from .models import DonoDaCarga, Motorista, Transporte

class DonoDaCargaSerializer(serializers.ModelSerializer):
    class Meta:
        model = DonoDaCarga
        fields = ['username', 'telefone', 'endereco', 'password']
        extra_kwargs = {'password': {'write_only': True}}

    def validate_username(self, value):
        if len(value) < 3:
            raise serializers.ValidationError("O nome de utilizador deve ter pelo menos 3 caracteres.")
        return value

    def validate_telefone(self, value):
        if not value.isdigit() or len(value) != 9:
            raise serializers.ValidationError("O número de telefone deve ter 9 dígitos.")
        if DonoDaCarga.objects.filter(telefone=value).exists():
            raise serializers.ValidationError("Este número de telefone já está em uso.")
        return value

    def validate_password(self, value):
        try:
            validate_password(value)
        except ValidationError as e:
            raise serializers.ValidationError(e.messages)
        return value

    def create(self, validated_data):
        user = DonoDaCarga.objects.create_user(**validated_data)
        return user

class MotoristaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Motorista
        fields = ['id', 'user', 'latitude', 'longitude', 'disponivel', 'veiculo', 'capacidade_carga']

class TransporteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transporte
        fields = '__all__'

class CadastroMotoristaSerializer(serializers.ModelSerializer):
    username = serializers.CharField(write_only=True)  # Campo para o nome de usuário
    password = serializers.CharField(write_only=True)  # Campo para a senha

    class Meta:
        model = Motorista
        fields = ['username', 'password', 'veiculo', 'capacidade_carga']

    def validate_username(self, value):
        if DonoDaCarga.objects.filter(username=value).exists():
            raise serializers.ValidationError("Este nome de usuário já está em uso.")
        return value

    def validate_password(self, value):
        try:
            validate_password(value)
        except ValidationError as e:
            raise serializers.ValidationError(e.messages)
        return value

    def create(self, validated_data):
        # Cria o usuário (DonoDaCarga)
        user = DonoDaCarga.objects.create_user(
            username=validated_data['username'],
            password=validated_data['password']
        )
        # Cria o motorista associado ao usuário
        motorista = Motorista.objects.create(
            user=user,
            veiculo=validated_data['veiculo'],
            capacidade_carga=validated_data['capacidade_carga']
        )
        return motorista

class LoginMotoristaSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        username = data.get('username')
        password = data.get('password')

        if username and password:
            return data
        raise serializers.ValidationError("Nome de usuário e senha são obrigatórios.")