from django.contrib import admin
from .models import DonoDaCarga, Motorista

# Registro do modelo DonoDaCarga
@admin.register(DonoDaCarga)
class DonoDaCargaAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'telefone', 'endereco')

# Registro do modelo Motorista
@admin.register(Motorista)
class MotoristaAdmin(admin.ModelAdmin):
    list_display = ('user', 'veiculo', 'capacidade_carga', 'disponivel')
    search_fields = ('user__username', 'veiculo')
    list_filter = ('disponivel',)