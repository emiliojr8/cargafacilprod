from django.urls import path
from .views import (
    CadastroView, LoginView, MotoristaDisponivelView, SolicitarTransporteView,
    DonosDeCargaProximosView, ListarSolicitacoesView,
    CadastroMotoristaView, LoginMotoristaView, ListarSolicitacoesMotoristaView
)

urlpatterns = [
    # Endpoints gerais
    path('cadastro/', CadastroView.as_view(), name='cadastro'),
    path('login/', LoginView.as_view(), name='login'),
    path('motoristas-disponiveis/', MotoristaDisponivelView.as_view(), name='motoristas-disponiveis'),
    path('solicitar-transporte/<int:motorista_id>/', SolicitarTransporteView.as_view(), name='solicitar-transporte'),
    path('donos-de-carga-proximos/', DonosDeCargaProximosView.as_view(), name='donos-de-carga-proximos'),
    path('solicitar-transporte/', SolicitarTransporteView.as_view(), name='solicitar-transporte'),
    path('solicitacoes/', ListarSolicitacoesView.as_view(), name='listar-solicitacoes'),

    # Endpoints específicos para motoristas
    path('cadastro-motorista/', CadastroMotoristaView.as_view(), name='cadastro-motorista'),
    path('login-motorista/', LoginMotoristaView.as_view(), name='login-motorista'),
    path('solicitacoes-motorista/', ListarSolicitacoesMotoristaView.as_view(), name='listar-solicitacoes-motorista'),
]