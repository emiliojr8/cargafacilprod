from django.apps import AppConfig


class OldDonoDaCargaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.old_dono_da_carga'
