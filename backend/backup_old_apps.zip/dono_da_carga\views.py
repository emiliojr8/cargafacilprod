from django.shortcuts import render
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import authenticate, login
from .serializers import DonoDaCargaSerializer, MotoristaSerializer, TransporteSerializer, CadastroMotoristaSerializer, LoginMotoristaSerializer
from rest_framework import generics
from .models import Motorista, DonoDaCarga, Transporte
from django.contrib.gis.geos import Point
from django.contrib.gis.db.models.functions import Distance
from rest_framework_simplejwt.tokens import RefreshToken

class CadastroView(APIView):
    def post(self, request):
        serializer = DonoDaCargaSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {'message': 'Registo realizado com sucesso!', 'data': serializer.data},
                status=status.HTTP_201_CREATED
            )
        return Response(
            {'message': 'Erro no registo. Verifique os dados.', 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )

class LoginView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return Response(
                {'message': 'Login realizado com sucesso!'},
                status=status.HTTP_200_OK
            )
        return Response(
            {'message': 'Credenciais inválidas. Verifique o nome de utilizador e a senha.'},
            status=status.HTTP_401_UNAUTHORIZED
        )

class MotoristaDisponivelView(generics.ListAPIView):
    queryset = Motorista.objects.filter(disponivel=True)
    serializer_class = MotoristaSerializer

class SolicitarTransporteView(APIView):
    def post(self, request):
        partida = request.data.get('partida')
        destino = request.data.get('destino')
        tipoCarga = request.data.get('tipoCarga')
        dimensoes = request.data.get('dimensoes')

        if not partida or not destino:
            return Response(
                {'message': 'Partida e destino são obrigatórios.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        transporte = Transporte.objects.create(
            partida=partida,
            destino=destino,
            tipoCarga=tipoCarga,
            dimensoes=dimensoes,
            usuario=request.user
        )
        return Response(
            {'message': 'Transporte solicitado com sucesso!', 'data': transporte.id},
            status=status.HTTP_201_CREATED
        )

class ListarSolicitacoesView(generics.ListAPIView):
    queryset = Transporte.objects.all()
    serializer_class = TransporteSerializer

class DonosDeCargaProximosView(APIView):
    def get(self, request):
        latitude = request.query_params.get('latitude', None)
        longitude = request.query_params.get('longitude', None)

        if not latitude or not longitude:
            return Response(
                {'message': 'Localização do motorista não fornecida.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        motorista_location = Point(float(longitude), float(latitude), srid=4326)
        donos_proximos = DonoDaCarga.objects.annotate(
            distancia=Distance('localizacao', motorista_location)
        ).filter(distancia__lte=10000)  # 10 km em metros

        serializer = DonoDaCargaSerializer(donos_proximos, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class CadastroMotoristaView(APIView):
    def post(self, request):
        serializer = CadastroMotoristaSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {'message': 'Motorista registrado com sucesso!', 'data': serializer.data},
                status=status.HTTP_201_CREATED
            )
        return Response(
            {'message': 'Erro no registro. Verifique os dados.', 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )

# View para login de motoristas
class LoginMotoristaView(APIView):
    def post(self, request):
        serializer = LoginMotoristaSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data['username']
            password = serializer.validated_data['password']
            user = authenticate(request, username=username, password=password)

            if user and hasattr(user, 'motorista'):  # Verifica se o usuário é um motorista
                login(request, user)
                refresh = RefreshToken.for_user(user)  # Gera o token JWT
                return Response({
                    'message': 'Login realizado com sucesso!',
                    'user_id': user.id,
                    'token': str(refresh.access_token),  # Retorna o token de acesso
                }, status=status.HTTP_200_OK)
            return Response(
                {'message': 'Credenciais inválidas ou usuário não é um motorista.'},
                status=status.HTTP_401_UNAUTHORIZED
            )
        return Response(
            {'message': 'Dados inválidos.', 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )

class ListarSolicitacoesMotoristaView(generics.ListAPIView):
    serializer_class = TransporteSerializer

    def get_queryset(self):
        motorista = self.request.user.motorista
        return Transporte.objects.filter(motorista=motorista)